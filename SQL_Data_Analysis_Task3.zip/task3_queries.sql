
CREATE DATABASE Ecommerce_SQL_Database;
USE Ecommerce_SQL_Database;

CREATE TABLE users (
    user_id INT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    country VARCHAR(50),
    signup_date DATE
);

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    user_id INT,
    order_date DATE,
    total_amount DECIMAL(10,2)
);

INSERT INTO users VALUES
(1,'Priya','priya@gmail.com','India','2024-01-10'),
(2,'Rahul','rahul@gmail.com','India','2024-02-15');

INSERT INTO orders VALUES
(1001,1,'2024-04-01',70000),
(1002,2,'2024-04-03',20000);

-- WHERE
SELECT * FROM orders WHERE total_amount > 20000;

-- HAVING
SELECT user_id, SUM(total_amount) AS total_spent
FROM orders
GROUP BY user_id
HAVING SUM(total_amount) > 50000;

-- ARPU
SELECT SUM(total_amount)/COUNT(DISTINCT user_id) AS ARPU
FROM orders;
